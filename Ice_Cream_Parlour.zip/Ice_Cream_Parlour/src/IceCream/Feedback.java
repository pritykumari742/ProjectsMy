package IceCream;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.sql.*;

@WebServlet("/Feedback")
public class Feedback extends HttpServlet
{
	private static final long serialVersionUID = 1L;
    public Feedback()
    {
        super();
    }
	
   

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{ 
		String name=request.getParameter("name");
		String phone=request.getParameter("phone");
		String email=request.getParameter("email");
		String address=request.getParameter("address");
		String feedback=request.getParameter("feedback");
		
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/icecream","root","");
			String sql="insert into feedback(name,phone,email,address,feedback)values(?,?,?,?,?)";
			PreparedStatement ps =con.prepareStatement(sql);
			
			ps.setString(1,name);
			ps.setString(2,phone);
			ps.setString(3,email);
			ps.setString(4, address);
			ps.setString(5,feedback);
			
			int i=ps.executeUpdate();
    	    if(i>0)
    	    {
    	    	response.sendRedirect("feedback.jsp");				
    	    }
    	    else
    	    {
    	    	PrintWriter out=response.getWriter();
				out.println("<script>alert('Not Payment')</script>");
    	    }
    	    
    	}
    	
     catch(Exception e)
    	{
    	e.printStackTrace();
    	}
    }  

}
