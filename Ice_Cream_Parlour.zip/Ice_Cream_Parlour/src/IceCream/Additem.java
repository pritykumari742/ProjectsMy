package IceCream;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import java.sql.*;

@WebServlet("/Additem")
@MultipartConfig(maxFileSize=16777215)  // used if image add to table
public class Additem extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
    public Additem()
    {
        super();
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{  
		String pname=request.getParameter("pname");
   	    String ptype=request.getParameter("ptype");
   	    
   	    InputStream inputStream=null;
   	    Part filePart=request.getPart("photo");
   	    
   	    String price=request.getParameter("price");
   	    String noofitem=request.getParameter("noofitem");
   	 
   	    if( filePart!=null)
   	    {
   		  inputStream=filePart.getInputStream();
   	    }
		 
		
		try
	      {
	    	  Class.forName("com.mysql.jdbc.Driver");
			  Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/icecream","root","");
			  String sql="insert into item(pname,ptype,photo,price,noofitem)values(?,?,?,?,?)";
			  PreparedStatement ps=con.prepareStatement(sql);
			  
			  ps.setString(1,pname);
			  ps.setString(2,ptype);
			  ps.setBlob(3,inputStream);
			  ps.setString(4,price);
			  ps.setString(5,noofitem);
			  
			  int i=	ps.executeUpdate();
			  if(i>0)
			  {
				  PrintWriter out = response.getWriter();
				  out.println("<script>alert('item insert successfully');window.location.href='additems.jsp;'</script>");
			  }
			  else
			  {
				  request.setAttribute("message","error inserting fail");
			  }
	      }
	      catch(Exception e)
	      {
	    		e.printStackTrace();
	      }
	 
     }

}
