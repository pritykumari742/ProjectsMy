package IceCream;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.sql.*;



@WebServlet("/Deleteitem")
public class Deleteitem extends HttpServlet
{ private static final long serialVersionUID = 1L;
    public Deleteitem()
    {super();}

	
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
	 try 
	 {
	    	int pid=Integer.parseInt(request.getParameter("pid"));
	    	Class.forName("com.mysql.jdbc.Driver");
	    	Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/icecream","root","");
	    	Statement stmt=con.createStatement();
	    	String query="Delete  from item where pid="+pid;
	    	int i=stmt.executeUpdate(query);
			if(i>0)
	    	{
				String ptype = request.getParameter("ptype");
				response.sendRedirect("deleteitem.jsp?ptype="+ptype);	
			}
			else
			{
				PrintWriter out=response.getWriter();
	    	    out.println("<script>alert('No Record Deleted')</script>");
			}
	 }
	 catch(Exception e)
	 {
		 e.printStackTrace();
	 }
	    	  	
	}

}
