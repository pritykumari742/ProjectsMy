package IceCream;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.sql.*;


@WebServlet("/Addemployee")
public class Addemployee extends HttpServlet 
{private static final long serialVersionUID = 1L;
 public Addemployee() {super();}

	
    
		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
		{
			String empname=request.getParameter("empname");
			String qualification=request.getParameter("qualification");
			String joiningdate=request.getParameter("joiningdate");
			String address=request.getParameter("address");
				
		   try
			{
				Class.forName("com.mysql.jdbc.Driver");
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/icecream","root","");
				String sql="insert into employee (empname,qualification,joiningdate,address)values(?,?,?,?)";
				PreparedStatement ps =con.prepareStatement(sql);
				
				ps.setString(1,empname);
				ps.setString(2,qualification);
				ps.setString(3,joiningdate);
				ps.setString(4,address);
				
				int i=ps.executeUpdate();
	    	    if(i>0)
	    	    {
	    	    	PrintWriter out = response.getWriter();
					out.println("<script>alert('employee insert successfully');window.location.href='addemployee.jsp;'</script>");
	    	    }
	    	    else
	    	    {
	    	    	PrintWriter out=response.getWriter();
					out.println("<script>alert('Not success')</script>");
	    	    }
	    	    
	    	}
	    	
	      catch(Exception e)
	    	{
	    	   e.printStackTrace();
	    	}
	    }
 }