package IceCream;
import java.io.IOException;

import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.sql.*;


@WebServlet("/Login")
public class Login extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
    public Login() 
    {
     super();
     }

   

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{ 
		int id=0;
		String name=request.getParameter("name");
    	String password=request.getParameter("password");
    	String dbname=null;
    	String dbpassword=null;
    	//String msg=null;
		
		try
        {
        	Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/icecream","root","");
			String sql="select * from register where name=? and password=?";
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, name);
			ps.setString(2,password);
			ResultSet rs=ps.executeQuery();
            PrintWriter out=response.getWriter();
			while(rs.next())
			{
			   id = rs.getInt("id");
			   dbname=rs.getString(2);
			   dbpassword=rs.getString(3);
			}
			if(name.equals(dbname)&& password.equals(dbpassword))
			{
				//......... Code for session...............
				HttpSession session=request.getSession();
				session.setAttribute("name",name);
				session.setAttribute("id",id);
			    response.sendRedirect("product.jsp");
		    }
			else
			{
				//msg ="username and password are worng";
				//request.setAttribute("msg",msg);
			   out.println("<script>alert('please register before login')</script>");
			   response.sendRedirect("login.jsp");
			  
			}
        }
        
        catch(Exception e)
        {
        	e.printStackTrace();
        }
	}
	}
