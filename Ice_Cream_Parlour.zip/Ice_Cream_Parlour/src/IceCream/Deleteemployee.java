package IceCream;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.sql.*;



@WebServlet("/Deleteemployee")
public class Deleteemployee extends HttpServlet
{ private static final long serialVersionUID = 1L;
    public Deleteemployee()
    {super();}

	
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
	 try {
	    	int empid=Integer.parseInt(request.getParameter("empid"));
	    	Class.forName("com.mysql.jdbc.Driver");
	    	Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/icecream","root","");
	    	Statement stmt=con.createStatement();
	    	String query="Delete  from employee where empid="+empid;
	    	int i=stmt.executeUpdate(query);
			if(i>0)
	    	{
				PrintWriter out = response.getWriter();
				out.println("<script>alert('employee delete successfully');window.location.href='deleteemployee.jsp;'</script>");
	    	}
			else
			{
				PrintWriter out=response.getWriter();
	    	    out.println("<script>alert('No Record Deleted')</script>");
			}
	 }
	 catch(Exception e)
	 {
		 e.printStackTrace();
	 }
	    	  	
	}

}
