package IceCream;

import java.io.IOException;

import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.sql.*;

@WebServlet("/Register")
public class Register extends HttpServlet
{
	private static final long serialVersionUID = 1L;
    public Register()
    {
        super();
    }
	
   

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{ 
		String name=request.getParameter("name");
		String password=request.getParameter("password");
		String retypepassword=request.getParameter("retypepassword");
		String phonenumber=request.getParameter("phonenumber");
		String address=request.getParameter("address");
		
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/icecream","root","");
			String sql="insert into register(name,password,retypepassword,phonenumber,address)values(?,?,?,?,?)";
			PreparedStatement ps =con.prepareStatement(sql);
			
			ps.setString(1,name);
			ps.setString(2,password);
			ps.setString(3,retypepassword);
			ps.setString(4, phonenumber);
			ps.setString(5,address);
			
			int i=ps.executeUpdate();
    	    if(i>0)
    	    {
    	      response.sendRedirect("login.jsp");
    	    }
    	    else
    	    {
    	    	PrintWriter out=response.getWriter();
				out.println("<script>alert('Not Registered')</script>");
    	    }
    	    
    	}
    	
     catch(Exception e)
    	{
    	e.printStackTrace();
    	}
    }  

}
