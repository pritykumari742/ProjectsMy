package IceCream;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.sql.*;

@WebServlet("/Payment")
public class Payment extends HttpServlet
{
	private static final long serialVersionUID = 1L;
    public Payment()
    {
        super();
    }
	
   

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{ 
		String name=request.getParameter("name");
		String phone=request.getParameter("phone");
		String card=request.getParameter("card");
		String presentaddress=request.getParameter("presentaddress");
		String permanentaddress=request.getParameter("permanentaddress");
		
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/icecream","root","");
			String sql="insert into payment(name,phone,card,presentaddress,permanentaddress)values(?,?,?,?,?)";
			PreparedStatement ps =con.prepareStatement(sql);
			
			ps.setString(1,name);
			ps.setString(2,phone);
			ps.setString(3,card);
			ps.setString(4, presentaddress);
			ps.setString(5,permanentaddress);
			
			int i=ps.executeUpdate();
    	    if(i>0)
    	    {
    	    	PrintWriter out=response.getWriter();
				out.println("<script>alert('Payment successfull');window.location.href='payment.jsp;'</script>");
				
    	    }
    	    else
    	    {
    	    	PrintWriter out=response.getWriter();
				out.println("<script>alert('Not Payment')</script>");
    	    }
    	    
    	}
    	
     catch(Exception e)
    	{
    	e.printStackTrace();
    	}
    }  

}
