package IceCream;

import java.io.IOException;

import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import java.sql.*;



@WebServlet("/Updateemployee")
public class Updateemployee extends HttpServlet {
	private static final long serialVersionUID = 1L;  
       public Updateemployee() {
        super();
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		int empid=Integer.parseInt(request.getParameter("empid"));
		String empname=request.getParameter("empname");
		String qualification=request.getParameter("qualification");
		String joiningdate=request.getParameter("joiningdate");
		String address=request.getParameter("address");
			
	try
	{
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/icecream","root","");
		String sql="Update employee set empname=?,qualification=?,joiningdate=?,address=?  where empid=?";
		PreparedStatement ps=con.prepareStatement(sql);
	
		ps.setString(1,empname);
		ps.setString(2, qualification);
		ps.setString(3, joiningdate);
		ps.setString(4, address);
		ps.setInt(5,empid);
		
		int i=ps.executeUpdate();
		if(i>0)
		{
			 PrintWriter out = response.getWriter();
			 out.println("<script>alert('update successfully');window.location.href='updateemployee.jsp;'</script>");
		}
		else
		{
			PrintWriter out=response.getWriter();
			out.println("<script>alert(' No Employee update successfully')</script>");
			
		}
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	}

}
